This is the camera tools "TOOLS_TOP/input" folder.

It contains input files and images used by camera tools.
