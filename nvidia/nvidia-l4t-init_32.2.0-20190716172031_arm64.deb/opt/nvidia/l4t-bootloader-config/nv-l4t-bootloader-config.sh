#!/bin/bash
# Copyright (c) 2019, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

# This script runs on target to check if need to update QSPI partitions for Nano
# If the running system version match the bootloader debian package,
# then check the VER in QSPI, if the VER is less then running system version,
# install the package to update QSPI.

BOOT_CTRL_CONF="/etc/nv_boot_control.conf"
T210REF_UPDATER="/usr/sbin/l4t_payload_updater_t210"
PACKAGE_DIR="/opt/nvidia/l4t-packages/bootloader"
PACKAGE_NAME="nvidia-l4t-bootloader"
deb_package=

# When create image, user may flash device with symlik board
# config name or orignal name, so the nv_boot_control.conf
# may have different board name informaton.
# Unify it to "jetson-*"
t210ref_update_boot_ctrl_conf() {
	tnspec=$( awk '/TNSPEC/ {print $2}' "${BOOT_CTRL_CONF}" )

	# "jetson-nano-emmc" for "p3448-0000-emmc"
	# "jetson-nano-qspi" for "p3448-0000"
	# "jetson-nano-qspi-sd" for "p3448-0000-sd"
	# "jetson-tx1" for "p2371-2180-devkit"
	if [[ "${tnspec}" == *"p3448-0000-emmc"* ]]; then
		sed -i 's/p3448-0000-emmc/jetson-nano-emmc/g' "${rootfs_dir}/etc/nv_boot_control.conf";
	elif [[ "${tnspec}" == *"p3448-0000-sd"* ]]; then
		sed -i 's/p3448-0000-sd/jetson-nano-qspi-sd/g' "${rootfs_dir}/etc/nv_boot_control.conf";
	elif [[ "${tnspec}" == *"p3448-0000"* ]]; then
		sed -i 's/p3448-0000/jetson-nano-qspi/g' "${rootfs_dir}/etc/nv_boot_control.conf";
	elif [[ "${tnspec}" == *"p2371-2180-devkit"* ]]; then
		sed -i 's/p2371-2180-devkit/jetson-tx1/g' "${rootfs_dir}/etc/nv_boot_control.conf";
	fi
}

# check qspi version, if need update it.
# return:  0: needs update; 1: doesn't need update.
t210ref_update_qspi_check () {
	# 1. get installed bootloader package's version
	# sample: ii  nvidia-l4t-bootloader  32.2.0-20190514154120  arm64  NVIDIA Bootloader Package
	# installed_deb_ver=32.2.0-20190514154120
	installed_deb_ver="$(dpkg -l | grep "${PACKAGE_NAME}" | awk '/'${PACKAGE_NAME}'/ {print $3}')"
	if [ -z "${installed_deb_ver}" ]; then
		return 1
	fi

	# 2. get debian package version, it should be same as installed package.
	# sample: nvidia-l4t-bootloader_32.2.0-20190514154120_arm64.deb
	# deb_version=32.2.0
        deb_package_name="${PACKAGE_NAME}""_""${installed_deb_ver}""_arm64.deb"
	deb_package="${PACKAGE_DIR}/${deb_package_name}"
	if [ -f "${deb_package}" ]; then
		deb_version="$(dpkg --info "${deb_package}" | grep "Version")"
		deb_version="$(echo "${deb_version}" | awk '/Version/ {print $2}' | cut -d "-" -f 1)"
	else
		return 1
	fi

	# 3. use deb_version as sys_version
	# sample: sys_rel=32, sys_maj_rev=2, sys_min_rev=0
	sys_rel="$(echo "${deb_version}" | cut -d "." -f 1)"
	sys_maj_rev="$(echo "${deb_version}" | cut -d "." -f 2)"
	sys_min_rev="$(echo "${deb_version}" | cut -d "." -f 3)"
	sys_version="${sys_rel}.${sys_maj_rev}.${sys_min_rev}"

	# read VER partition to get QSPI version
	if [ -x "${T210REF_UPDATER}" ]; then
		ver_info="$(${T210REF_UPDATER} -v)"
		if [ "${ver_info}" == "NV1" ]; then
			qspi_rel=31
			qspi_maj_rev=0
			qspi_min_rev=0
		else
			rel_number="$(echo "${ver_info}" | awk '/#/ {print $2}')"
			qspi_rel="$(echo "${rel_number}" | sed 's/R//')"

			# get revision=2.0
			revision=$(echo "${ver_info}" | awk '/#/ {print $5}')
			revision="$(echo "${revision}" | sed 's/,//')"

			# get maj_rev=2, min_rev=0
			qspi_maj_rev="$(echo "${revision}" | cut -d "." -f 1)"
			qspi_min_rev="$(echo "${revision}" | cut -d "." -f 2)"
		fi
	else
		return 1
	fi

	if (( "${sys_rel}" > "${qspi_rel}" )); then
		# sys_rel > qspi_rel
		# need to update QSPI
		return 0
	elif (( "${sys_rel}" == "${qspi_rel}" )); then
		if (( "${sys_maj_rev}" > "${qspi_maj_rev}" )); then
			# sys_rel == qspi_rel
			# sys_maj_rev > qspi_maj_rev
			# need to update QSPI
			return 0
		elif (( "${sys_maj_rev}" == "${qspi_maj_rev}" )); then
			if (( "${sys_min_rev}" > "${qspi_min_rev}" )); then
				# sys_rel == qspi_rel
				# sys_maj_rev == qspi_maj_rev
				# sys_min_rev > qspi_min_rev
				# need to update QSPI
				return 0
			else
				return 1
			fi
		else
			return 1
		fi
	else
		return 1
	fi
}

t210ref_update_qspi () {
	if t210ref_update_qspi_check; then
		dpkg -i "${deb_package}"
	fi
}

if [ ! -r "${BOOT_CTRL_CONF}" ]; then
	echo "Error. Cannot open ${BOOT_CTRL_CONF} for reading."
	echo "Cannot install package. Exiting..."
	exit 1
fi

chipid=$( awk '/TEGRA_CHIPID/ {print $2}' "${BOOT_CTRL_CONF}" )

case "${chipid}" in
	0x21)
		t210ref_update_boot_ctrl_conf
		t210ref_update_qspi
		;;
	*)
		echo "Error. Unsupported chip ID: ${chipid}."
		echo "Cannot install package. Exiting..."
		exit 1
esac
